package es.ua.eps.viewmodel.ui;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import es.ua.eps.viewmodel.R;

public class MainActivity extends AppCompatActivity {

    Button buttonViewModelSumar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        configView();

    }

    private void configView(){
        buttonViewModelSumar = findViewById(R.id.mainActivityBt);
        buttonViewModelSumar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(getApplicationContext(), ViewModelSumarActivity.class));
            }
        });
    }

}