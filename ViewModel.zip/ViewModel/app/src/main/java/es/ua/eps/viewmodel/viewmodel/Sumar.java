package es.ua.eps.viewmodel.viewmodel;

public class Sumar {

    public static final int sumar(int numero){
        numero = numero +1;
        return numero;
    }
}
