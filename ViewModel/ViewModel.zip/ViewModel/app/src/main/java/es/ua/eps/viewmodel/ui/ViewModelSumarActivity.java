package es.ua.eps.viewmodel.ui;

import android.arch.lifecycle.ViewModelProviders;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import es.ua.eps.viewmodel.R;
import es.ua.eps.viewmodel.viewmodel.Sumar;
import es.ua.eps.viewmodel.viewmodel.SumarViewModel;

public class ViewModelSumarActivity extends AppCompatActivity {

    private TextView tvSumar, TvSumarViewModel;
    private Button btSumar;

    private int numero;
    private SumarViewModel sumarViewModel;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_view_model_sumar);

        configView();

    }

    private void configView(){

        sumarViewModel = ViewModelProviders.of(this).get(SumarViewModel.class);

        tvSumar = findViewById(R.id.textViewSumar1);
        TvSumarViewModel = findViewById(R.id.textViewSumar2);
        btSumar = findViewById(R.id.buttonSumar);

        tvSumar.setText(" " + numero);
        //tvSumar.setText(" " + sumarViewModel.getResultado());

        TvSumarViewModel.setText(" " + sumarViewModel.getResultado());


        btSumar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                // MÉTODO TRADICIONAL. AÑADIMOS SETTEXT DE UNA VARIABLE
                // NUMÉRICA NORMAL.

                numero = Sumar.sumar(numero);
                tvSumar.setText(" " + numero);
                //sumarViewModel.setResultado(Sumar.sumar(sumarViewModel.getResultado()));
                //tvSumar.setText(" " + sumarViewModel.getResultado());


                //MÉTODO VIEW MODEL, VA POR OTRA VÍA. NO USA LA VARIABLE NUMERO.
                sumarViewModel.setResultado(Sumar.sumar(sumarViewModel.getResultado()));
                TvSumarViewModel.setText(" " + sumarViewModel.getResultado());

            }
        });
    }




}